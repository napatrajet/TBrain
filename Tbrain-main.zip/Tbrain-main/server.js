/* ===================================================
   server.js — TBrain (lowdb version)
   แทนที่ MAMP + api.php ด้วย Node.js + Express + lowdb

   วิธีใช้:
   1. npm install
   2. node server.js
   3. เปิดเบราว์เซอร์ไปที่ http://localhost:8888
   =================================================== */

const express  = require('express');
const path     = require('path');
const low      = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');

/* ── Setup lowdb ── */
const adapter = new FileSync(path.join(__dirname, 'db.json'));
const db      = low(adapter);

/* โครงสร้างเริ่มต้น */
db.defaults({
  users:    [],   // { id, name, age, email, streak, totalSessions, createdAt }
  sessions: [],   // { id, userId, mode, category, level, score, accuracy, pairs, timeUsed, avgLatency, timestamp }
  stats:    {}    // { [userId]: { progress, latencies_fi, day_YYYY-MM-DD, streak, totalSessions } }
}).write();

/* ── Express app ── */
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/* Serve static files (HTML/CSS/JS) จากโฟลเดอร์เดียวกัน */
app.use(express.static(__dirname));

/* ── Utility ── */
function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/* ═══════════════════════════════════════════
   POST /api  — รับทุก action แบบเดียวกับ api.php
═══════════════════════════════════════════ */
app.post('/api', (req, res) => {
  const { action, ...data } = req.body;

  try {
    switch (action) {

      /* ── Login ─────────────────────────── */
      case 'login': {
        const user = db.get('users').find({ email: data.email }).value();
        if (!user) return res.json({ ok: false, error: 'ไม่พบบัญชีนี้' });
        /* (demo: ไม่เข้ารหัส password — production ควรใช้ bcrypt) */
        if (user.password !== data.password)
          return res.json({ ok: false, error: 'รหัสผ่านไม่ถูกต้อง' });
        const { password: _, ...safeUser } = user;
        return res.json({ ok: true, user: safeUser });
      }

      /* ── Register ──────────────────────── */
      case 'register': {
        const exists = db.get('users').find({ email: data.email }).value();
        if (exists) return res.json({ ok: false, error: 'อีเมลนี้ถูกใช้งานแล้ว' });
        const newUser = {
          id:            genId(),
          name:          data.name   || 'ผู้ใช้',
          age:           parseInt(data.age) || 0,
          email:         data.email,
          password:      data.password,  /* demo เท่านั้น */
          streak:        0,
          totalSessions: 0,
          createdAt:     new Date().toISOString()
        };
        db.get('users').push(newUser).write();
        const { password: _, ...safeUser } = newUser;
        return res.json({ ok: true, user: safeUser });
      }

      /* ── Guest login ───────────────────── */
      case 'guest': {
        const guestUser = {
          id:            genId(),
          name:          'ผู้เล่นแขก',
          age:           0,
          email:         '',
          isGuest:       true,
          streak:        0,
          totalSessions: 0,
          createdAt:     new Date().toISOString()
        };
        db.get('users').push(guestUser).write();
        return res.json({ ok: true, user: guestUser });
      }

      /* ── Save session ───────────────────── */
      case 'save_session': {
        const sess = {
          id:         genId(),
          userId:     data.userId,
          mode:       data.mode       || '',
          category:   data.category   || '',
          level:      data.level      || 1,
          score:      data.score      || 0,
          accuracy:   data.accuracy   || 0,
          pairs:      data.pairs      || 0,
          timeUsed:   data.timeUsed   || 0,
          avgLatency: data.avgLatency || 0,
          timestamp:  new Date().toISOString()
        };
        db.get('sessions').push(sess).write();

        /* อัปเดต totalSessions ของ user */
        db.get('users')
          .find({ id: data.userId })
          .assign({ totalSessions: (db.get('users').find({ id: data.userId }).value()?.totalSessions || 0) + 1 })
          .write();

        return res.json({ ok: true, session: sess });
      }

      /* ── Save stats ─────────────────────── */
      case 'save_stats': {
        const uid     = data.userId;
        const current = db.get('stats').get(uid).value() || {};
        const merged  = deepMerge(current, data.stats || data);
        db.get('stats').set(uid, merged).write();
        return res.json({ ok: true });
      }

      /* ── Update user ────────────────────── */
      case 'update_user': {
        const uid = data.userId;
        const { userId: _u, ...patch } = data;
        db.get('users').find({ id: uid }).assign(patch).write();
        return res.json({ ok: true });
      }

      /* ── Get progress ───────────────────── */
      case 'get_progress': {
        const uid      = data.userId;
        const stats    = db.get('stats').get(uid).value() || {};
        const sessions = db.get('sessions')
          .filter({ userId: uid })
          .sortBy('timestamp')
          .reverse()
          .take(300)
          .value();
        return res.json({ ok: true, stats, sessions });
      }

      /* ── Get user ───────────────────────── */
      case 'get_user': {
        const user = db.get('users').find({ id: data.userId }).value();
        if (!user) return res.json({ ok: false, error: 'ไม่พบผู้ใช้' });
        const { password: _, ...safeUser } = user;
        return res.json({ ok: true, user: safeUser });
      }

      /* ── Edit user (name/age/email/password) ── */
      case 'edit_user': {
        const uid  = data.userId;
        const user = db.get('users').find({ id: uid }).value();
        if (!user) return res.json({ ok: false, error: 'ไม่พบผู้ใช้' });
        const patch = {};
        if (data.name     !== undefined) patch.name     = data.name;
        if (data.age      !== undefined) patch.age      = parseInt(data.age) || 0;
        if (data.email    !== undefined) patch.email    = data.email;
        if (data.password !== undefined && data.password !== '') patch.password = data.password;
        db.get('users').find({ id: uid }).assign(patch).write();
        const { password: _, ...safeUser } = db.get('users').find({ id: uid }).value();
        return res.json({ ok: true, user: safeUser });
      }

      /* ── Delete user ────────────────────── */
      case 'delete_user': {
        const uid = data.userId;
        db.get('users').remove({ id: uid }).write();
        db.get('sessions').remove({ userId: uid }).write();
        if (db.get('stats').value()[uid]) {
          db.get('stats').unset(uid).write();
        }
        return res.json({ ok: true });
      }

      default:
        return res.json({ ok: false, error: 'Unknown action: ' + action });
    }
  } catch (err) {
    console.error('API error:', err);
    return res.status(500).json({ ok: false, error: err.message });
  }
});

/* ── Deep merge helper ── */
function deepMerge(target, source) {
  const out = Object.assign({}, target);
  for (const key of Object.keys(source)) {
    if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
      out[key] = deepMerge(target[key] || {}, source[key]);
    } else if (Array.isArray(source[key])) {
      out[key] = source[key];
    } else {
      out[key] = source[key];
    }
  }
  return out;
}

/* ── Debug: ดูข้อมูลใน db.json ── */
app.get('/debug/db', (req, res) => {
  const users    = db.get('users').map(u => { const {password:_,...s}=u; return s; }).value();
  const sessions = db.get('sessions').value();
  const stats    = db.get('stats').value();
  res.json({ users, sessions, stats });
});

/* ══════════════════════════════════════════════
   ADMIN API  — password-protected
   Header: x-admin-key: tbrain_admin_2024
══════════════════════════════════════════════ */
const ADMIN_KEY = 'tbrain_admin_2024';

function requireAdmin(req, res, next) {
  const key = req.headers['x-admin-key'] || req.query.key;
  if (key !== ADMIN_KEY) return res.status(401).json({ ok: false, error: 'Unauthorized' });
  next();
}

/* GET /admin/data — ดูข้อมูลทั้งหมด + search/filter */
app.get('/admin/data', requireAdmin, (req, res) => {
  const { search, mode, category } = req.query;
  let users    = db.get('users').map(u => { const {password:_,...s}=u; return s; }).value();
  let sessions = db.get('sessions').value();

  // Search users by name or email
  if (search) {
    const q = search.toLowerCase();
    users = users.filter(u =>
      (u.name||'').toLowerCase().includes(q) ||
      (u.email||'').toLowerCase().includes(q)
    );
    const matchIds = new Set(users.map(u => u.id));
    sessions = sessions.filter(s => matchIds.has(s.userId));
  }
  // Filter sessions by mode
  if (mode)     sessions = sessions.filter(s => s.mode === mode);
  // Filter sessions by category
  if (category) sessions = sessions.filter(s => s.category === category);

  // Summary report
  const report = {
    totalUsers:    db.get('users').size().value(),
    totalSessions: db.get('sessions').size().value(),
    avgAccuracy:   sessions.length
      ? Math.round(sessions.reduce((a,s)=>a+(s.accuracy||0),0) / sessions.length) : 0,
    modeBreakdown: ['image','word-image','register','bilingual'].map(m => ({
      mode: m,
      count: db.get('sessions').filter({mode:m}).size().value(),
      avgAcc: (() => {
        const ms = db.get('sessions').filter({mode:m}).value();
        return ms.length ? Math.round(ms.reduce((a,s)=>a+(s.accuracy||0),0)/ms.length) : 0;
      })()
    }))
  };

  res.json({ ok: true, users, sessions, report });
});

/* DELETE /admin/user/:id — ลบ user (admin only) */
app.delete('/admin/user/:id', requireAdmin, (req, res) => {
  const uid = req.params.id;
  db.get('users').remove({ id: uid }).write();
  db.get('sessions').remove({ userId: uid }).write();
  if (db.get('stats').value()[uid]) db.get('stats').unset(uid).write();
  res.json({ ok: true, deleted: uid });
});

/* ── Admin HTML page ── */
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin.html'));
});

/* ── Fallback → index.html ── */
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

/* ── Start server ── */
const PORT = process.env.PORT || 8888;
app.listen(PORT, () => {
  console.log(`\n🌱 Tbrain server running at http://localhost:${PORT}`);
  console.log(`📂 Serving files from: ${__dirname}`);
  console.log(`💾 Database: ${path.join(__dirname, 'db.json')}\n`);
});

