/* ===== PROFILE.JS ===== */

/* คำนวณ streak จาก sessions จริง */
function calcStreak(sessions) {
  if (!sessions.length) return 0;
  const DAY = 86400000;
  const days = new Set(sessions.map(s => {
    const d = new Date(s.ts); d.setHours(0,0,0,0); return d.getTime();
  }));
  let streak = 0;
  const today = new Date(); today.setHours(0,0,0,0);
  let checkTs = today.getTime();
  if (!days.has(checkTs)) checkTs -= DAY;
  while (days.has(checkTs) && streak <= 365) { streak++; checkTs -= DAY; }
  return streak;
}

/* ── render stats จาก sessions array ── */
function renderProfileStats(sessions) {
  const streak     = calcStreak(sessions);
  const totalScore = sessions.reduce((a, b) => a + (b.score || 0), 0);
  const avgAcc     = sessions.length
    ? Math.round(sessions.reduce((a, b) => a + (b.accuracy || 0), 0) / sessions.length)
    : 0;

  document.getElementById('ssStreak').textContent   = streak;
  document.getElementById('ssSessions').textContent = sessions.length;
  document.getElementById('ssTotal').textContent    = totalScore;

  // ── Badges ──
  const badges = [];
  if (streak >= 3)           badges.push('🔥 ' + streak + ' วันติดต่อกัน');
  if (sessions.length >= 10) badges.push('🎮 ' + sessions.length + ' เซสชัน');
  if (avgAcc >= 80)          badges.push('🎯 แม่นยำ ' + avgAcc + '%');
  if (sessions.length >= 50) badges.push('🏆 นักฝึกตัวยง');
  const modeSet = new Set(sessions.map(s => s.mode));
  if (modeSet.size >= 4)     badges.push('🌟 ครบทุกโหมด');

  const badgeEl = document.getElementById('profileBadges');
  if (badgeEl) {
    badgeEl.innerHTML = badges.length
      ? badges.map(b => `<span class="profile-badge">${b}</span>`).join('')
      : '<span style="color:var(--text-soft);font-size:0.83rem;">เริ่มเล่นเพื่อรับ badge!</span>';
  }
}

window.addEventListener('load', async () => {
  const user = AppState.user;
  if (!user) { window.location.href = 'index.html'; return; }

  // ── ข้อมูลผู้ใช้ ──
  document.getElementById('profileName').textContent   = user.name || 'ผู้ใช้';
  document.getElementById('profileAge').textContent    = user.age  ? user.age + ' ปี' : '—';
  document.getElementById('profileAvatar').textContent = user.age >= 70 ? '🧓' : user.age >= 60 ? '👴' : '😊';

  // ── แสดง localStorage ก่อน (เร็ว) และเก็บ reference ไว้ให้ shareReport ใช้ ──
  window._currentUserSessions = AppState.sessions;
  renderProfileStats(window._currentUserSessions);

  // ── sync จาก server แล้ว merge เพื่อให้ครบ ──
  try {
    if (!user.id) throw new Error('no userId');
    const res = await apiPost('get_progress', { userId: user.id });
    if (res.ok && Array.isArray(res.sessions) && res.sessions.length) {
      // กรอง: เอาเฉพาะ sessions ที่เป็นของ user คนนี้เท่านั้น
      const ownSess = res.sessions.filter(s => s.userId === user.id);

      // server sessions ใช้ field "timestamp" (ISO) → แปลงเป็น ts (unix ms)
      const serverSess = ownSess.map(s => ({
        mode:     s.mode     || '',
        category: s.category || '',
        accuracy: s.accuracy || 0,
        score:    s.score    || 0,
        pairs:    s.pairs    || 0,
        total:    s.total    || s.pairs || 0,
        errors:   s.errors   || 0,
        timeUsed: s.timeUsed || 0,
        ts: s.timestamp ? new Date(s.timestamp).getTime() : 0,
      })).filter(s => s.ts > 0);   // กรองออก session ที่ ts เป็น 0

      // merge: เอา localStorage เป็นหลัก, เพิ่ม server session ที่ไม่มีใน localStorage
      const local   = AppState.sessions;
      const localTs = new Set(local.map(s => s.ts));
      const extra   = serverSess.filter(s => !localTs.has(s.ts));
      const merged  = [...local, ...extra].sort((a, b) => (b.ts || 0) - (a.ts || 0));

      // save กลับ localStorage เพื่อ session ถัดไปไม่ต้อง fetch ใหม่
      if (extra.length) {
        const key = 'mg_sessions_' + user.id;
        localStorage.setItem(key, JSON.stringify(merged.slice(0, 300)));
      }

      window._currentUserSessions = merged;   // อัปเดต reference ให้ shareReport ใช้
      renderProfileStats(merged);
    }
  } catch (e) {
    // server down หรือ error — ใช้ localStorage ที่ render ไปแล้ว
  }
});

function changeFontSize(sz, btn) {
  document.querySelectorAll('.fs-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const sizes = { sm:'15px', md:'18px', lg:'22px' };
  document.documentElement.style.fontSize = sizes[sz] || '18px';
  localStorage.setItem('mg_fontsize', sz);
  showToast('ขนาดตัวอักษร: ' + ({sm:'เล็ก', md:'กลาง', lg:'ใหญ่'}[sz] || ''), '', 1500);
}

// restore active button ตาม setting ที่บันทึกไว้
window.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('mg_fontsize') || 'md';
  const btn = document.getElementById('fs-' + saved);
  if (btn) { document.querySelectorAll('.fs-btn').forEach(b => b.classList.remove('active')); btn.classList.add('active'); }
});
function saveSetting(k, v) { const s=AppState.stats; s['setting_'+k]=v; AppState.saveStats(s); }
function toggleFamily() {
  const toggle=document.getElementById('familyToggle');
  toggle.checked=!toggle.checked;
  apiPost('revoke_family',{user_id:AppState.user?.id}).catch(()=>{});
  showToast(toggle.checked?'เปิดการแชร์กับครอบครัว':'ปิดการแชร์กับครอบครัว','',2000);
}
function shareReport() {
  const user = AppState.user;
  if (!user) return;

  // ใช้ sessions ที่ sync มาแล้วตอนโหลดหน้า (ครบกว่า localStorage อย่างเดียว)
  const sessions = window._currentUserSessions || AppState.sessions;
  const streak   = calcStreak(sessions);
  const avgAcc   = sessions.length
    ? Math.round(sessions.reduce((a, b) => a + (b.accuracy || 0), 0) / sessions.length)
    : 0;

  // คำนวณ accuracy ต่อโหมด
  const MODES = [
    { key: 'register',   icon: '📜', label: 'ภาษาทางการ' },
    { key: 'bilingual',  icon: '🌐', label: 'สองภาษา' },
    { key: 'image',      icon: '🖼️', label: 'จำภาพ' },
    { key: 'word-image', icon: '🔤', label: 'คำ+ภาพ' },
  ];
  const modeLines = MODES.map(m => {
    const ms  = sessions.filter(s => s.mode === m.key);
    if (!ms.length) return null;
    const acc = Math.round(ms.reduce((a, s) => a + (s.accuracy || 0), 0) / ms.length);
    return `${m.icon} ${m.label}: ${acc}% (${ms.length} ครั้ง)`;
  }).filter(Boolean);

  const today = new Date().toLocaleDateString('th-TH', { day:'numeric', month:'long', year:'numeric' });
  const report = [
    '📊 รายงาน TBrain',
    `👤 ${user.name}`,
    `📅 ${today}`,
    `🔥 เล่นต่อเนื่อง: ${streak} วัน`,
    `🎯 เล่นทั้งหมด: ${sessions.length} ครั้ง`,
    `📈 ความแม่นยำเฉลี่ย: ${avgAcc}%`,
    ...(modeLines.length ? ['', '── รายละเอียดโหมด ──', ...modeLines] : [])
  ].join('\n');

  // แสดง modal preview แล้วให้เลือก copy / share
  let modal = document.getElementById('share-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'share-modal';
    modal.style.cssText = `
      position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;
      display:flex;align-items:center;justify-content:center;padding:20px;`;
    modal.innerHTML = `
      <div style="background:var(--surface,#fff);border-radius:16px;padding:28px 24px;
                  max-width:400px;width:100%;box-shadow:0 12px 40px rgba(0,0,0,.3);">
        <h3 style="margin:0 0 14px;font-size:1rem;">📤 แชร์รายงานให้ผู้ดูแล</h3>
        <pre id="share-text" style="background:var(--bg-secondary,#f4f4f4);border-radius:10px;
             padding:14px;font-family:inherit;font-size:0.85rem;white-space:pre-wrap;
             word-break:break-word;margin:0 0 18px;max-height:260px;overflow-y:auto;"></pre>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
          <button onclick="copyReport()" style="flex:1;padding:10px;border:none;border-radius:8px;
            background:var(--primary,#4e9af1);color:#fff;font-family:inherit;
            font-size:0.9rem;cursor:pointer;">📋 คัดลอก</button>
          <button id="share-native-btn" onclick="nativeShare()" style="flex:1;padding:10px;border:none;
            border-radius:8px;background:var(--secondary,#6c757d);color:#fff;font-family:inherit;
            font-size:0.9rem;cursor:pointer;display:none;">📨 แชร์</button>
          <button onclick="document.getElementById('share-modal').remove()"
            style="padding:10px 18px;border:1px solid var(--border,#ccc);border-radius:8px;
            background:transparent;font-family:inherit;font-size:0.9rem;cursor:pointer;">ปิด</button>
        </div>
        <p style="margin:12px 0 0;font-size:0.75rem;color:var(--text-soft,#888);">
          คัดลอกแล้วนำไปวางใน Discord ของผู้ดูแล</p>
      </div>`;
    document.body.appendChild(modal);
    modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
  }

  modal.querySelector('#share-text').textContent = report;
  window._shareReportText = report;

  // แสดงปุ่ม Share ถ้า Web Share API รองรับ
  const nativeBtn = modal.querySelector('#share-native-btn');
  if (navigator.share) nativeBtn.style.display = '';

  document.getElementById('share-modal').style.display = 'flex';
}

function copyReport() {
  const text = window._shareReportText || '';
  navigator.clipboard?.writeText(text).then(() => {
    showToast('คัดลอกรายงานแล้ว ✅', 'success', 2000);
  }).catch(() => {
    // fallback สำหรับ browser เก่า
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta);
    ta.select(); document.execCommand('copy');
    ta.remove();
    showToast('คัดลอกรายงานแล้ว ✅', 'success', 2000);
  });
  document.getElementById('share-modal')?.remove();
}

function nativeShare() {
  const text = window._shareReportText || '';
  navigator.share({ title: 'รายงาน TBrain', text }).catch(() => {});
  document.getElementById('share-modal')?.remove();
}
function doLogout() {
  if(confirm('ต้องการออกจากระบบ?')) { localStorage.removeItem('mg_user'); window.location.href='index.html'; }
}
