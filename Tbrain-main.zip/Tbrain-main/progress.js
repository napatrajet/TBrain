/* ===== PROGRESS.JS ===== */

let currentPeriod = 'week';

window.addEventListener('load', () => {
  if(!AppState.user) { window.location.href='index.html'; return; }
  loadProgress();
});

async function loadProgress() {
  // Try API first, fall back to local
  const res = await apiGet('get_stats', { user_id: AppState.user?.id });
  const data = (res.ok && res.data) ? res.data : AppState.stats;

  renderRadar(data.progress || {});
  renderTrend(data);
  renderHeatmap();
  renderSessions();
  renderInsight(data);

  if(data.latency_alert) {
    document.getElementById('alertBanner').style.display='flex';
  }
}

// ===== RADAR CHART (Canvas) =====
function renderRadar(progress) {
  const canvas = document.getElementById('radarChart');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  const cx = W/2, cy = H/2, R = W*0.38;
  const axes = [
    progress.visual  || 0,
    progress.vocab   || 0,
    progress.formal  || 0,
    progress.spell   || 0,
    progress.bi      || 0,
  ];
  const N = 5;

  ctx.clearRect(0,0,W,H);

  // Background rings
  for(let ring=1; ring<=5; ring++) {
    const r = R * ring/5;
    ctx.beginPath();
    for(let i=0;i<N;i++){
      const a = (i/N)*Math.PI*2 - Math.PI/2;
      const x = cx + r*Math.cos(a), y = cy + r*Math.sin(a);
      i===0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
    }
    ctx.closePath();
    ctx.strokeStyle = 'rgba(45,125,210,0.12)';
    ctx.lineWidth = 1;
    ctx.stroke();
    if(ring===5){ ctx.fillStyle='rgba(45,125,210,0.03)'; ctx.fill(); }
  }

  // Axis lines
  for(let i=0;i<N;i++){
    const a=(i/N)*Math.PI*2-Math.PI/2;
    ctx.beginPath();
    ctx.moveTo(cx,cy);
    ctx.lineTo(cx+R*Math.cos(a), cy+R*Math.sin(a));
    ctx.strokeStyle='rgba(45,125,210,0.15)'; ctx.lineWidth=1; ctx.stroke();
  }

  // Target (100%)
  ctx.beginPath();
  for(let i=0;i<N;i++){
    const a=(i/N)*Math.PI*2-Math.PI/2;
    const x=cx+R*Math.cos(a), y=cy+R*Math.sin(a);
    i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
  }
  ctx.closePath();
  ctx.fillStyle='rgba(45,125,210,0.06)'; ctx.fill();
  ctx.strokeStyle='rgba(45,125,210,0.2)'; ctx.lineWidth=1.5; ctx.stroke();

  // Data polygon
  ctx.beginPath();
  for(let i=0;i<N;i++){
    const a=(i/N)*Math.PI*2-Math.PI/2;
    const v=axes[i]/100;
    const x=cx+R*v*Math.cos(a), y=cy+R*v*Math.sin(a);
    i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
  }
  ctx.closePath();
  ctx.fillStyle='rgba(45,125,210,0.25)'; ctx.fill();
  ctx.strokeStyle='#2D7DD2'; ctx.lineWidth=2.5; ctx.stroke();

  // Dots
  for(let i=0;i<N;i++){
    const a=(i/N)*Math.PI*2-Math.PI/2;
    const v=axes[i]/100;
    const x=cx+R*v*Math.cos(a), y=cy+R*v*Math.sin(a);
    ctx.beginPath(); ctx.arc(x,y,5,0,Math.PI*2);
    ctx.fillStyle='#2D7DD2'; ctx.fill();
    ctx.strokeStyle='#fff'; ctx.lineWidth=2; ctx.stroke();
  }
}

// ===== TREND LINE CHART =====
function renderTrend(stats) {
  const canvas = document.getElementById('trendChart');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  const W=canvas.width, H=canvas.height, pad=28;

  // Generate mock trend from sessions
  const sessions = AppState.sessions;
  const days = 30;
  const formalByDay={}, informalByDay={};

  sessions.forEach(s=>{
    const d=s.ts?new Date(s.ts).toISOString().slice(0,10):'';
    if(!d) return;
    const diff=Math.floor((Date.now()-new Date(d).getTime())/86400000);
    if(diff>days) return;
    if(s.mode==='formal-informal'){
      if(!formalByDay[d]){ formalByDay[d]=[]; }
      formalByDay[d].push(s.accuracy||0);
    } else {
      if(!informalByDay[d]){ informalByDay[d]=[]; }
      informalByDay[d].push(s.accuracy||0);
    }
  });

  const labels=[],fArr=[],iArr=[];
  for(let i=days-1;i>=0;i--){
    const d=new Date(Date.now()-i*86400000).toISOString().slice(0,10);
    labels.push(d.slice(5));
    fArr.push(formalByDay[d]   ? Math.round(formalByDay[d].reduce((a,b)=>a+b,0)/formalByDay[d].length)   : null);
    iArr.push(informalByDay[d] ? Math.round(informalByDay[d].reduce((a,b)=>a+b,0)/informalByDay[d].length) : null);
  }

  ctx.clearRect(0,0,W,H);
  const plotW=W-pad*2, plotH=H-pad*2;

  // Grid
  for(let g=0;g<=4;g++){
    const y=pad+plotH*(1-g/4);
    ctx.beginPath(); ctx.moveTo(pad,y); ctx.lineTo(W-pad,y);
    ctx.strokeStyle='rgba(0,0,0,0.06)'; ctx.lineWidth=1; ctx.stroke();
    ctx.fillStyle='#8A9BB0'; ctx.font='10px Sarabun,sans-serif';
    ctx.fillText((g*25)+'%', 2, y+4);
  }

  // Draw lines
  function drawLine(data, color) {
    ctx.beginPath(); let started=false;
    data.forEach((v,i)=>{
      if(v===null) return;
      const x=pad+i*(plotW/(labels.length-1)), y=pad+plotH*(1-v/100);
      if(!started){ ctx.moveTo(x,y); started=true; } else ctx.lineTo(x,y);
    });
    ctx.strokeStyle=color; ctx.lineWidth=2.5; ctx.lineJoin='round'; ctx.stroke();
    // Dots
    data.forEach((v,i)=>{
      if(v===null) return;
      const x=pad+i*(plotW/(labels.length-1)), y=pad+plotH*(1-v/100);
      ctx.beginPath(); ctx.arc(x,y,4,0,Math.PI*2);
      ctx.fillStyle=color; ctx.fill();
    });
  }

  drawLine(iArr, '#27AE60');
  drawLine(fArr, '#2D7DD2');
}

// ===== HEATMAP =====
function renderHeatmap() {
  const grid = document.getElementById('heatmapGrid');
  if(!grid) return;

  // Use session data to build heatmap
  const wordCount = {};
  AppState.sessions.forEach(s=>{
    if(s.mode==='formal-informal'||s.mode==='thai-english') {
      // stub: pull word from cat
    }
  });

  // Static demo heatmap using formal-informal data
  const demo = [
    {word:'รับประทาน',status:'green'},{word:'อย่างไร',status:'green'},
    {word:'เหตุใด',status:'yellow'},{word:'แพทย์',status:'yellow'},
    {word:'มหัศจรรย์',status:'red'},{word:'อนุมัติ',status:'red'},
    {word:'กล่าว',status:'green'},{word:'สอบถาม',status:'green'},
    {word:'โลหิต',status:'yellow'},{word:'วินิจฉัย',status:'red'},
    {word:'ศัลยกรรม',status:'red'},{word:'ใบอนุญาตขับรถ',status:'yellow'},
    {word:'ชำระเงิน',status:'green'},{word:'ดำเนินการ',status:'green'},
  ];

  grid.innerHTML = demo.map(w=>
    `<div class="hm-word ${w.status}" title="${w.word}">${w.word}</div>`
  ).join('');
}

// ===== SESSION LIST =====
function renderSessions() {
  const el = document.getElementById('sessionList');
  if(!el) return;
  const sessions = AppState.sessions.slice(0,15);
  if(!sessions.length) { el.innerHTML='<div style="text-align:center;color:var(--text-muted);padding:20px;">ยังไม่มีประวัติการเล่น</div>'; return; }

  const modeIcon = {
    'image-image':'🖼️', 'image-word':'📖',
    'formal-informal':'🗣️', 'thai-english':'🌐'
  };
  const modeLabel = {
    'image-image':'จับคู่ภาพ','image-word':'ภาพและคำ',
    'formal-informal':'พูดและเขียน','thai-english':'ไทยและอังกฤษ'
  };

  el.innerHTML = sessions.map(s=>{
    const icon  = modeIcon[s.mode]||'🎮';
    const label = modeLabel[s.mode]||s.mode;
    const date  = s.ts ? new Date(s.ts).toLocaleDateString('th-TH',{day:'numeric',month:'short'}) : '';
    return `<div class="session-item">
      <div class="si-icon">${icon}</div>
      <div class="si-body">
        <div class="si-title">${label} — ${date}</div>
        <div class="si-sub">ระดับ ${s.level||1} | ${s.accuracy||0}% ถูกต้อง | ${s.pairs||0} คู่</div>
      </div>
      <div class="si-score">${s.score||0}⭐</div>
    </div>`;
  }).join('');
}

// ===== WEEKLY INSIGHT =====
function renderInsight(stats) {
  const el = document.getElementById('weeklyInsight');
  if(!el) return;
  const prog = stats.progress||{};
  const formal = prog.formal||0;
  const visual = prog.visual||0;
  const texts = [];
  if(formal >= 60) texts.push('คำศัพท์ภาษาทางการดีขึ้น '+formal+'%');
  else texts.push('ยังควรฝึกภาษาเขียนทางการ (ปัจจุบัน '+formal+'%)');
  if(visual >= 70) texts.push('ความจำภาพยอดเยี่ยมที่ '+visual+'%');
  else texts.push('ลองฝึกจับคู่ภาพเพิ่มเติมเพื่อพัฒนาความจำภาพ');
  el.textContent = texts.join(' • ');
}

function setPeriod(p,btn) {
  currentPeriod=p;
  document.querySelectorAll('.period-tab').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  loadProgress();
}
