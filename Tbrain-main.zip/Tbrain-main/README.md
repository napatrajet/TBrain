****🧠 TBrain (LowDB NoSQL Version)****

โปรเจกต์ TBrain เวอร์ชั่นน้ำหนักเบา (Lightweight) ที่เปลี่ยนมาใช้ LowDB แทนฐานข้อมูลแบบเดิม ทำให้ไม่ต้องตั้งค่า Server ฐานข้อมูลให้ยุ่งยาก

🛠 สิ่งที่ต้องมีก่อนเริ่ม (Prerequisites)
Node.js: แนะนำเวอร์ชัน LTS (ดาวน์โหลดได้ที่ nodejs.org)

****ไม่ต้องมี MAMP, XAMPP หรือ PHP ใดๆ ทั้งสิ้น****

****🚀 ขั้นตอนการติดตั้งและรัน****
1. ติดตั้ง Dependencies
เปิด Terminal หรือ Command Prompt ในโฟลเดอร์โปรเจกต์ แล้วใช้คำสั่ง:

****Bash****

npm install

2. เริ่มต้นการทำงาน (Start Server)
รันคำสั่งเพื่อเปิดใช้งาน Server:

****Bash****

node server.js

3. เข้าใช้งานโปรแกรม
เปิด Web Browser แล้วเข้าไปที่:

        🔗 http://localhost:8888

****📂 การเก็บข้อมูล (Data Storage)****

ระบบนี้ทำงานในรูปแบบ NoSQL โดยข้อมูลทั้งหมดจะถูกจัดเก็บไว้ในไฟล์ JSON เพียงไฟล์เดียว:

ตำแหน่งไฟล์: db.json (อยู่ในโฟลเดอร์หลักของโปรเจกต์)

ข้อมูลที่เก็บ: ข้อมูลผู้ใช้ (Users), เซสชัน (Sessions) และสถิติต่างๆ (Stats)

วิธีตรวจสอบข้อมูล: * เปิดไฟล์ db.json โดยตรงด้วยโปรแกรม Text Editor
หรือตรวจสอบผ่าน Browser ที่: 

        🔗http://localhost:8888/debug/db

จุดเด่นของเวอร์ชันนี้

Zero Config: ไม่ต้องตั้งค่า Database Username/Password

Portable: ย้ายโฟลเดอร์ไปเครื่องไหนก็ทำงานต่อได้ทันที

Simple: แก้ไขข้อมูลได้ง่ายๆ ผ่านไฟล์ JSON

---

## 🛡️ Admin Panel

### เข้าถึง Admin Panel

เปิด Browser แล้วไปที่:

```
🔗 http://localhost:8888/admin
```

### วิธี Login

| ช่อง | ค่า |
|------|-----|
| Admin Key | `tbrain_admin_2024` |

> ⚠️ **หมายเหตุ:** Admin Key ถูกกำหนดไว้ใน `server.js` บรรทัด `const ADMIN_KEY = 'tbrain_admin_2024'` หากต้องการเปลี่ยนให้แก้ไขค่านี้แล้ว restart server

### ฟีเจอร์ใน Admin Panel

**📊 ความคืบหน้า (Progress)**
- ดูสถิติรวมของทุกผู้ใช้ (จำนวน Users, Sessions, ความแม่นยำเฉลี่ย, Active วันนี้)
- ตารางแสดง progress ของแต่ละ user: accuracy bar, โหมดที่เล่น, streak, วันที่เล่นล่าสุด
- ค้นหา user ตามชื่อ และกรองตามโหมด (Color / Number / Shape / Mixed)
- แก้ไขข้อมูล user ได้จากปุ่ม ✏️

**👥 จัดการผู้ใช้ (Users)**
- ตารางรายชื่อ user ทั้งหมด พร้อมข้อมูล ชื่อ / อายุ / อีเมล / วันที่สมัคร
- แก้ไขข้อมูล user (ชื่อ, อายุ, อีเมล, รหัสผ่าน)
- ลบบัญชี user พร้อมข้อมูลทั้งหมด

### Security

Admin Panel ถูกป้องกันด้วย `x-admin-key` header middleware — ผู้ใช้ทั่วไปไม่สามารถเข้าถึง `/admin/*` routes ได้ เนื่องจากต้องใช้ Admin Key ในทุก request ที่ส่งไปยัง server

