/* ===================================================
   app.js — TBrain (lowdb / Node.js version)
   เปลี่ยน API_BASE จาก api.php → /api (Express)
   =================================================== */

/* ══ FONT SIZE — apply ทันทีก่อน render ══ */
(function applyFontSize() {
  const map = { sm: '15px', md: '18px', lg: '22px' };
  const saved = localStorage.getItem('mg_fontsize') || 'md';
  document.documentElement.style.fontSize = map[saved] || '18px';
})();

/* ══════════════════════════════════════════════════
   TOAST
══════════════════════════════════════════════════ */
function showToast(msg, type = '', duration = 2200) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.className = 'toast show ' + type;
  clearTimeout(t._to);
  t._to = setTimeout(() => t.classList.remove('show'), duration);
}

/* ══════════════════════════════════════════════════
   USER STATE  (localStorage + server sync)
══════════════════════════════════════════════════ */
const AppState = {
  get user() {
    try { return JSON.parse(localStorage.getItem('mg_user') || 'null'); } catch { return null; }
  },
  set user(v) { localStorage.setItem('mg_user', JSON.stringify(v)); },

  get stats() {
    try { return JSON.parse(localStorage.getItem('mg_stats') || '{}'); } catch { return {}; }
  },
  saveStats(patch) {
    const s = this.stats;
    Object.assign(s, patch);
    localStorage.setItem('mg_stats', JSON.stringify(s));
    /* Sync ไป server ด้วย (ไม่รอผล) */
    const uid = this.user?.id;
    if (uid) {
      apiPost('save_stats', { userId: uid, stats: s }).catch(() => {});
    }
  },

  get sessKey() {
    try { return 'mg_sessions_' + (this.user?.id || 'guest'); } catch { return 'mg_sessions_guest'; }
  },
  get sessions() {
    try { return JSON.parse(localStorage.getItem(this.sessKey) || '[]'); } catch { return []; }
  },
  addSession(sess) {
    const arr = this.sessions;
    arr.unshift({ ...sess, ts: Date.now() });
    if (arr.length > 200) arr.splice(200);
    localStorage.setItem(this.sessKey, JSON.stringify(arr));
  }
};

/* ══════════════════════════════════════════════════
   SOUND
══════════════════════════════════════════════════ */
const SoundFX = {
  ctx: null, enabled: true,
  init() { if (!this.ctx) this.ctx = new (window.AudioContext || window.webkitAudioContext)(); },
  beep(freq = 440, type = 'sine', vol = 0.18, dur = 0.12) {
    if (!this.enabled) return;
    try {
      this.init();
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.connect(g); g.connect(this.ctx.destination);
      o.frequency.value = freq; o.type = type;
      g.gain.setValueAtTime(vol, this.ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + dur);
      o.start(); o.stop(this.ctx.currentTime + dur);
    } catch (e) {}
  },
  correct()  { this.beep(660, 'sine', 0.2, 0.15); setTimeout(() => this.beep(880, 'sine', 0.15, 0.1), 80); },
  wrong()    { this.beep(220, 'sawtooth', 0.18, 0.2); },
  flip()     { this.beep(440, 'sine', 0.1, 0.08); },
  complete() { this.beep(523,'sine',0.2,0.15); setTimeout(()=>this.beep(659,'sine',0.2,0.15),120); setTimeout(()=>this.beep(784,'sine',0.25,0.2),240); }
};

/* ══════════════════════════════════════════════════
   HAPTIC
══════════════════════════════════════════════════ */
function haptic(pattern = [10]) {
  try { if (navigator.vibrate) navigator.vibrate(pattern); } catch (e) {}
}

/* ══════════════════════════════════════════════════
   DATE HELPERS
══════════════════════════════════════════════════ */
function todayStr() {
  return new Date().toLocaleDateString('th-TH', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

/* ══════════════════════════════════════════════════
   SHUFFLE
══════════════════════════════════════════════════ */
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* ══════════════════════════════════════════════════
   SETTINGS MODAL
══════════════════════════════════════════════════ */
function openSettings() {
  const m = document.getElementById('settingsModal');
  if (m) m.classList.add('open');
}
function closeSettings(e) {
  if (e && e.target !== document.getElementById('settingsModal')) return;
  const m = document.getElementById('settingsModal');
  if (m) m.classList.remove('open');
}

/* ══════════════════════════════════════════════════
   ZOOM TIP
══════════════════════════════════════════════════ */
function showZoom(text) {
  const z = document.getElementById('zoomTip');
  if (!z) return;
  z.textContent = text;
  z.classList.add('show');
  clearTimeout(z._zt);
  z._zt = setTimeout(() => z.classList.remove('show'), 1800);
}

/* ══════════════════════════════════════════════════
   API HELPER  ← เปลี่ยนจาก data/api.php → /api
══════════════════════════════════════════════════ */
const API_BASE = '/api';

async function apiPost(action, payload = {}) {
  try {
    const res = await fetch(API_BASE, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ action, ...payload })
    });
    return await res.json();
  } catch (e) {
    console.warn('API offline, using local storage');
    return { ok: false, offline: true };
  }
}

async function apiGet(action, params = {}) {
  try {
    const q   = new URLSearchParams({ action, ...params }).toString();
    const res = await fetch(`${API_BASE}?${q}`);
    return await res.json();
  } catch (e) {
    return { ok: false, offline: true };
  }
}

/* ══════════════════════════════════════════════════
   SCORE CALCULATOR
══════════════════════════════════════════════════ */
function calcScore({ correct, total, timeLeft, maxTime, combo, level }) {
  const base       = correct * (10 + level * 5);
  const timeBonus  = Math.floor((timeLeft / maxTime) * 50);
  const comboBonus = combo > 1 ? combo * 8 : 0;
  const accuracy   = total > 0 ? Math.round((correct / total) * 100) : 0;
  return { score: base + timeBonus + comboBonus, accuracy };
}
